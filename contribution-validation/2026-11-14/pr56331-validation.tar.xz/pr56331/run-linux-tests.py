"""Verify mounted source blobs and run the full nine suites on Linux."""

import hashlib
import json
import os
from pathlib import Path
import sys
import time

import pytest
import torch
import transformers
import vllm


REPORT = Path('/reports')
ROOT = Path('/workspace')
manifest = json.loads((REPORT / 'source-manifest.json').read_text())
assert Path(vllm.__file__).resolve() == ROOT / 'vllm/__init__.py'
assert not torch.cuda.is_initialized()


def verify_sources():
    for entry in manifest['files']:
        path = ROOT / entry['path']
        data = os.readlink(path).encode() if entry['mode'] == '120000' else path.read_bytes()
        sha = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        assert sha == entry['sha'], entry['path']


verify_sources()
receipt = {
    'validated_tree': manifest['tree'],
    'source_files_verified': len(manifest['files']),
    'merged_upstream': manifest['main'],
    'source': str(vllm.__file__), 'python': sys.version,
    'torch': torch.__version__, 'transformers': transformers.__version__,
    'platform': sys.platform, 'cuda_before': torch.cuda.is_initialized(),
    'tests': manifest['tests'], 'gpu_validation_rerun': False,
    'prior_gpu_validation_commit': 'ba29c63bbaa130128268b9b65c0a0e4cfd85a38f',
}
print(json.dumps(receipt), flush=True)
started = time.monotonic()
code = pytest.main([
    '-q', '-rs', '--junitxml=/reports/tests-linux.xml',
    '-o', 'cache_dir=/tmp/pr56331-pytest-cache', *manifest['tests'],
])
verify_sources()
receipt.update(exit_code=int(code), elapsed_seconds=time.monotonic() - started,
               cuda_after=torch.cuda.is_initialized(), source_files_verified_after=True)
(REPORT / 'tests-linux-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
assert not receipt['cuda_after']
raise SystemExit(code)
