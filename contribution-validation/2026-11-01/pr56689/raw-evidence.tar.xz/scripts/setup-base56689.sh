#!/bin/bash
set -euo pipefail
task_root=/home/shadeform/vllm-pr-validation-nov1
trap 'result=$?; printf "%s\n" "$result" > "$task_root/logs/install-base56689.exit"' EXIT
export UV_CACHE_DIR="$task_root/cache/uv"
export UV_PYTHON_INSTALL_DIR="$task_root/cache/python"
export VLLM_USE_PRECOMPILED=1
export VLLM_PRECOMPILED_WHEEL_VARIANT=cu130
export VLLM_PRECOMPILED_WHEEL_COMMIT=fe77d0906be0c38c5e2c575cd61b545a2fa687e4
git -C "$task_root/sources" worktree add --detach "$task_root/base56689" "$VLLM_PRECOMPILED_WHEEL_COMMIT"
cd "$task_root/base56689"
git rev-parse HEAD HEAD^{tree}
"$task_root/bin/uv" venv --python 3.12 .venv
export VIRTUAL_ENV="$PWD/.venv"
"$task_root/bin/uv" pip install --editable . --torch-backend=cu130
"$task_root/bin/uv" pip install pytest pytest-asyncio pytest-forked pytest-timeout pytest-shard pytest-rerunfailures pytest-cov tblib ninja 'ray[default]>=2.56.0,<2.57'
"$task_root/bin/uv" pip freeze > "$task_root/evidence/packages-base56689.txt"
date -u
