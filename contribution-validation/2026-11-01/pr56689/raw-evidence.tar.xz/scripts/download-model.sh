#!/bin/bash
set -euo pipefail
task_root=/home/shadeform/vllm-pr-validation-nov1
trap 'result=$?; printf "%s\n" "$result" > "$task_root/logs/download-model.exit"' EXIT
model_root="$task_root/models/Qwen3-0.6B-c1899de"
mkdir -p "$model_root"
date -u
for name in config.json generation_config.json merges.txt model.safetensors tokenizer.json tokenizer_config.json vocab.json; do
  curl --fail --location --retry 3 --output "$model_root/$name" "https://huggingface.co/Qwen/Qwen3-0.6B/resolve/c1899de289a04d12100db370d81485cdf75e47ca/$name"
done
"$task_root/pr56331/.venv/bin/python" - "$task_root" "$model_root" <<'PY'
import importlib.util
import json
from pathlib import Path
import sys
root, model = map(Path, sys.argv[1:])
spec = importlib.util.spec_from_file_location("fs_validation", root / "scripts/validate_fs_rope.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
result = module.verify_model(model, root / "scripts/model-revision-manifest.json")
(root / "evidence/model-download-verification.json").write_text(json.dumps(result, indent=2) + "\n")
print("Verified pinned model bytes", result["repo"], result["revision"])
PY
date -u
