#!/bin/bash
set -euo pipefail
task_root=/home/shadeform/vllm-pr-validation-nov1
trap 'result=$?; printf "%s\n" "$result" > "$task_root/logs/install-driver.exit"' EXIT
date -u
sudo -n env DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=l apt-get install -y --no-install-recommends \
  nvidia-driver-580-server-open=580.178.04-0ubuntu0.22.04.1 \
  nvidia-fabricmanager-580=580.178.04-0ubuntu0.22.04.1 \
  libnvidia-nscq-580=580.178.04-0ubuntu0.22.04.1 \
  linux-headers-5.15.0-101-generic
sudo -n modprobe nvidia
sudo -n modprobe nvidia_uvm
sudo -n modprobe nvidia_nvswitch
sudo -n systemctl enable --now nvidia-fabricmanager
nvidia-smi
nvidia-smi topo -m
sudo -n systemctl --no-pager status nvidia-fabricmanager
date -u
