#!/bin/bash
set -euo pipefail
task_root=/home/shadeform/vllm-pr-validation-nov1
trap 'result=$?; printf "%s\n" "$result" > "$task_root/logs/bootstrap-source.exit"' EXIT
export UV_CACHE_DIR="$task_root/cache/uv"
export UV_PYTHON_INSTALL_DIR="$task_root/cache/python"
export UV_NO_MODIFY_PATH=1
export UV_INSTALL_DIR="$task_root/bin"
export GIT_TERMINAL_PROMPT=0
mkdir -p "$UV_CACHE_DIR" "$UV_PYTHON_INSTALL_DIR" "$UV_INSTALL_DIR"
date -u
curl --fail --silent --show-error --location https://astral.sh/uv/install.sh -o "$task_root/scripts/uv-install.sh"
sha256sum "$task_root/scripts/uv-install.sh"
sh "$task_root/scripts/uv-install.sh"
"$task_root/bin/uv" --version
git init "$task_root/sources"
git -C "$task_root/sources" remote add origin https://github.com/vllm-project/vllm.git
git -C "$task_root/sources" fetch --no-tags --depth=60 origin \
  refs/pull/56331/head:refs/heads/pr56331 \
  refs/pull/56689/head:refs/heads/pr56689
test "$(git -C "$task_root/sources" rev-parse pr56331)" = ba29c63bbaa130128268b9b65c0a0e4cfd85a38f
test "$(git -C "$task_root/sources" rev-parse pr56689)" = 2f25de1c9d3a31160b7f2e789428f5129dd006dd
git -C "$task_root/sources" worktree add "$task_root/pr56331" pr56331
git -C "$task_root/sources" worktree add "$task_root/pr56689" pr56689
"$task_root/bin/uv" venv --python 3.12 "$task_root/pr56331/.venv"
"$task_root/bin/uv" venv --python 3.12 "$task_root/pr56689/.venv"
for commit in ed1a7307950ab5e6593d25123579ed7ca998b350 fe77d0906be0c38c5e2c575cd61b545a2fa687e4; do
  for variant in cu130 cu129; do
    curl --fail --silent --show-error --location "https://wheels.vllm.ai/$commit/$variant/vllm/metadata.json" -o "$task_root/evidence/wheel-metadata-$commit-$variant.json" || true
  done
done
date -u
