#!/bin/bash
set -euo pipefail
task_root=/home/shadeform/vllm-pr-validation-nov1
trap 'result=$?; printf "%s\n" "$result" > "$task_root/logs/install-cuda.exit"' EXIT
date -u
curl --fail --silent --show-error --location \
  https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-keyring_1.1-1_all.deb \
  -o "$task_root/scripts/cuda-keyring_1.1-1_all.deb"
sha256sum "$task_root/scripts/cuda-keyring_1.1-1_all.deb"
sudo -n dpkg -i "$task_root/scripts/cuda-keyring_1.1-1_all.deb"
sudo -n apt-get update
sudo -n env DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=l apt-get install -y --no-install-recommends \
  cuda-nvcc-13-0 cuda-cudart-dev-13-0 cuda-cccl-13-0 libcurand-dev-13-0
/usr/local/cuda-13.0/bin/nvcc --version
date -u
