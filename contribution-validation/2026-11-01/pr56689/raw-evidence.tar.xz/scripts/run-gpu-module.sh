#!/bin/bash
set -euo pipefail
task_root=/home/shadeform/vllm-pr-validation-nov1
trap 'result=$?; printf "%s\n" "$result" > "$task_root/logs/gpu-module56689.exit"' EXIT
deadline=$((SECONDS + 3600))
printf 'Waiting for all model validation jobs to finish.\n'
while true; do
  complete=1
  for job in gpu-pr56331 gpu-pr56689 gpu-baseline56689; do
    if [ -f "$task_root/logs/$job.exit" ]; then
      test "$(cat "$task_root/logs/$job.exit")" = 0 || exit 2
    else
      complete=0
    fi
  done
  test "$complete" = 1 && break
  test "$SECONDS" -lt "$deadline" || exit 3
  sleep 2
done
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
cd "$task_root/pr56689"
export PATH="$PWD/.venv/bin:/usr/local/cuda-13.0/bin:$PATH"
export PYTHONPATH="$PWD"
export CUDA_HOME=/usr/local/cuda-13.0
export CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7
export CUDA_DEVICE_ORDER=PCI_BUS_ID
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export VLLM_WORKER_MULTIPROC_METHOD=spawn
export RAY_TMPDIR="$(mktemp -d /tmp/vlray-nov1.XXXXXX)"
mkdir -p "$RAY_TMPDIR"
date -u
.venv/bin/python "$task_root/scripts/run_weight_module.py"
date -u
