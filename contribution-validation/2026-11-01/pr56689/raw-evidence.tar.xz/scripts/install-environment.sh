#!/bin/bash
set -euo pipefail
task_root=/home/shadeform/vllm-pr-validation-nov1
pr_number="$1"
case "$pr_number" in
  56331) wheel_commit=ed1a7307950ab5e6593d25123579ed7ca998b350 ;;
  56689) wheel_commit=fe77d0906be0c38c5e2c575cd61b545a2fa687e4 ;;
  *) exit 2 ;;
esac
trap 'result=$?; printf "%s\n" "$result" > "$task_root/logs/install-pr$pr_number.exit"' EXIT
export UV_CACHE_DIR="$task_root/cache/uv"
export UV_PYTHON_INSTALL_DIR="$task_root/cache/python"
export VLLM_USE_PRECOMPILED=1
export VLLM_PRECOMPILED_WHEEL_VARIANT=cu130
export VLLM_PRECOMPILED_WHEEL_COMMIT="$wheel_commit"
cd "$task_root/pr$pr_number"
export VIRTUAL_ENV="$PWD/.venv"
date -u
test -s "$task_root/evidence/wheel-metadata-$wheel_commit-cu130.json"
"$task_root/bin/uv" pip install --editable . --torch-backend=cu130
"$task_root/bin/uv" pip install pytest pytest-asyncio pytest-forked pytest-timeout 'ray[default]' huggingface-hub
.venv/bin/python -c 'import sys,torch,vllm,transformers,ray; print(sys.version); print("torch",torch.__version__,"cuda",torch.version.cuda); print("vllm",vllm.__version__,vllm.__file__); print("transformers",transformers.__version__,"ray",ray.__version__); print("CUDA available",torch.cuda.is_available(),"GPU count",torch.cuda.device_count())'
"$task_root/bin/uv" pip freeze > "$task_root/evidence/packages-pr$pr_number.txt"
date -u
