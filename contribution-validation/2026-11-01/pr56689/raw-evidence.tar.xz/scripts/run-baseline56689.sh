#!/bin/bash
set -euo pipefail
task_root=/home/shadeform/vllm-pr-validation-nov1
trap 'result=$?; printf "%s\n" "$result" > "$task_root/logs/gpu-baseline56689.exit"' EXIT
deadline=$((SECONDS + 2400))
printf 'Waiting for FS validation and the fixed TP2/PP2 arm to finish.\n'
while true; do
  if [ -f "$task_root/logs/gpu-pr56331.exit" ]; then
    test "$(cat "$task_root/logs/gpu-pr56331.exit")" = 0 || exit 2
    if [ -f "$task_root/evidence/pr56689-tp2-pp1-unpacked-attempt2/source-manifest.json" ]; then
      break
    fi
  fi
  if [ -f "$task_root/logs/gpu-pr56689.exit" ]; then
    test "$(cat "$task_root/logs/gpu-pr56689.exit")" = 0 || exit 2
  fi
  test "$SECONDS" -lt "$deadline" || exit 3
  sleep 2
done
test -z "$(nvidia-smi -i 3,4,5,6,7 --query-compute-apps=pid --format=csv,noheader)"
mkdir -p "$task_root/scripts-baseline56689"
for name in run_tied_weight_sync_validation.py tied_weight_probe.py launch_tied_weight_sync_validation.py source_provenance.py validate_fs_rope.py model-revision-manifest.json; do
  cp "$task_root/scripts/$name" "$task_root/scripts-baseline56689/$name"
done
cd "$task_root/base56689"
export PATH="$PWD/.venv/bin:/usr/local/cuda-13.0/bin:$PATH"
export PYTHONPATH="$PWD:$task_root/scripts-baseline56689"
export CUDA_HOME=/usr/local/cuda-13.0
export CUDA_DEVICE_ORDER=PCI_BUS_ID
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export VLLM_BATCH_INVARIANT=1
export VLLM_WORKER_MULTIPROC_METHOD=spawn
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export VLLM_NO_USAGE_STATS=1
export TIED_SYNC_SOURCE="$PWD"
export TIED_SYNC_HEAD=fe77d0906be0c38c5e2c575cd61b545a2fa687e4
export TIED_SYNC_TREE="$(git rev-parse HEAD^{tree})"
export TIED_SYNC_EXPECT_BUG=1
export TIED_SYNC_GPUS=3,4,5,6,7
export CUDA_VISIBLE_DEVICES="$TIED_SYNC_GPUS"
export TIED_SYNC_TP=2
export TIED_SYNC_PP=2
export TIED_SYNC_PACKED=1
export NO_PROXY=127.0.0.1,localhost
export no_proxy=127.0.0.1,localhost
date -u
.venv/bin/python "$task_root/scripts-baseline56689/launch_tied_weight_sync_validation.py" \
  --output "$task_root/evidence/base56689-tp2-pp2-packed-attempt1"
date -u
