#!/bin/bash
set -euo pipefail
task_root=/home/shadeform/vllm-pr-validation-nov1
trap 'result=$?; printf "%s\n" "$result" > "$task_root/logs/gpu-pr56689.exit"' EXIT
cd "$task_root/pr56689"
export PATH="$PWD/.venv/bin:/usr/local/cuda-13.0/bin:$PATH"
export CUDA_HOME=/usr/local/cuda-13.0
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export PYTHONPATH="$PWD:$task_root/scripts"
export VLLM_BATCH_INVARIANT=1
export TIED_SYNC_TP=2
export TIED_SYNC_PP=2
export TIED_SYNC_PACKED=1
export TIED_SYNC_GPUS=0,1,2,3,4
export CUDA_VISIBLE_DEVICES="$TIED_SYNC_GPUS"
export CUDA_DEVICE_ORDER=PCI_BUS_ID
export NO_PROXY=127.0.0.1,localhost
export no_proxy=127.0.0.1,localhost
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export VLLM_NO_USAGE_STATS=1
export VLLM_WORKER_MULTIPROC_METHOD=spawn
date -u
.venv/bin/python "$task_root/scripts/launch_tied_weight_sync_validation.py" \
  --output "$task_root/evidence/pr56689-tp2-pp2-packed-attempt2"
export TIED_SYNC_PP=1
export TIED_SYNC_PACKED=0
export TIED_SYNC_GPUS=0,1,2
export CUDA_VISIBLE_DEVICES="$TIED_SYNC_GPUS"
.venv/bin/python "$task_root/scripts/launch_tied_weight_sync_validation.py" \
  --output "$task_root/evidence/pr56689-tp2-pp1-unpacked-attempt2"
date -u
